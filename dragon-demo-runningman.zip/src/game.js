var Dragon = require('dragonjs'),
    Game = Dragon.Game,
    mainScreen = require('./screens/main.js'),
    getJSON = require('get-json');

Game.addScreens(mainScreen);
Game.run({
    debug: false
});

getJSON(
    'http://time.jsontest.com',
    function (err, res) {
        if (err) {
            console.log('something bad happened');
        } else {
            console.log(
                JSON.stringify(res, null, 3)
            );
        }
    }
);
